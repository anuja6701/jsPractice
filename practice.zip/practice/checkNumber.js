var  no=1234
var no1=4.949

function is_Integer(num)
{
    if(Number.isInteger(num))
        return "an integer";
    else
        return "not an integer"; 
}


console.log(no+" is "+is_Integer(no))

console.log(no1+" is "+is_Integer(no1))