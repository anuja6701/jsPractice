const date = new Date();

const date1 = date.toDateString();

console.log("Current Date: " + date1);
